package com.fitmax.ventas.repository;

import com.fitmax.ventas.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VentaRepository extends JpaRepository<Venta, Long> {
    // Al extender de JpaRepository, Spring Boot ya nos regala todos los 
    // métodos para guardar, buscar, actualizar y eliminar ventas en la base de datos.
}