package com.fitmax.ventas.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ventas")
public class Venta {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String cliente;
    private Double total;
    private LocalDateTime fecha;

    public Venta() {
    }

    public Venta(String cliente, Double total) {
        this.cliente = cliente;
        this.total = total;
        this.fecha = LocalDateTime.now();
    }

    public Long getId() { 
        return id; 
    }
    
    public void setId(Long id) { 
        this.id = id; 
    }
    
    public String getCliente() { 
        return cliente; 
    }
    
    public void setCliente(String cliente) { 
        this.cliente = cliente; 
    }
    
    public Double getTotal() { 
        return total; 
    }
    
    public void setTotal(Double total) { 
        this.total = total; 
    }
    
    public LocalDateTime getFecha() { 
        return fecha; 
    }
    
    public void setFecha(LocalDateTime fecha) { 
        this.fecha = fecha; 
    }
}