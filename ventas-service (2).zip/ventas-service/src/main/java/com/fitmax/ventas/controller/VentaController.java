package com.fitmax.ventas.controller;

import com.fitmax.ventas.model.Venta;
import com.fitmax.ventas.repository.VentaRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ventas")
public class VentaController {

    private final VentaRepository repository;

    // Inyección de dependencias a través del constructor
    public VentaController(VentaRepository repository) {
        this.repository = repository;
    }

    // Endpoint para obtener todas las ventas (Método GET)
    @GetMapping
    public List<Venta> getAll() {
        return repository.findAll();
    }

    // Endpoint para crear una nueva venta (Método POST)
    @PostMapping
    public Venta create(@RequestBody Venta venta) {
        return repository.save(venta);
    }
}